
  # UX Audit Tool - Hackathon 2025 - Dan Rahilly

  This is a code bundle for UX Audit Tool - Hackathon 2025 - Dan Rahilly. The original project is available at https://www.figma.com/design/BYWdXwJ0e1kU1VKYZlYybX/UX-Audit-Tool---Hackathon-2025---Dan-Rahilly.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  